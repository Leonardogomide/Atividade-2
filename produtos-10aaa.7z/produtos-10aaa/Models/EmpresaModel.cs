namespace emprese.Models
{
    public class Empresa
    {
        public int Id { get; set; }
      
        public string Nome { get; set; } = string.Empty;
        
        public decimal End { get; set; }
        
        public string Taxa { get; set; } = string.Empty;
        
        public string Registro { get; set; } = string.Empty;
        
        public string Cnpj { get; set; } = string.Empty;
        
        public DateTime Data { get; set; }
    }
}


