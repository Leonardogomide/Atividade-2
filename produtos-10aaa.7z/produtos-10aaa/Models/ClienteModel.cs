namespace cliente.Models
{
    public class Cliente
    {
        public int Id { get; set; }
      
        public string Nome { get; set; } = string.Empty;
        
        public decimal Cpf { get; set; }
        
        public string End { get; set; } = string.Empty;
        
        public string Tel { get; set; } = string.Empty;
        
        public string Email { get; set; } = string.Empty;
        
        public DateTime Data { get; set; }
    }
}
