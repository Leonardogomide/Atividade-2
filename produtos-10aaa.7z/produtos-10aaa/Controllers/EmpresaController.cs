using Microsoft.AspNetCore.Mvc;
using empresa.Models;


namespace empresa.Controllers
{
    public class ClienteController : Controller
    {
        public IActionResult Index()
        {


            var empresas = new List<Empresa>{


                new  empresa
                {
                    id = 1,
                    Nome = "Tech Solutions LTDA",
                    End = "Rua das Inovações, 123, São Paulo - SP",
                    Taxa = 15.5,
                    Reg = "Simples Nacional",
                    Cnpj = "12.345.678/0001-90"


                },
                new empresa
                {
                    Id = 2,
                    Nome = "Mundo Verde SA",
                    End = "Avenida Verde, 456, Rio de Janeiro - RJ",
                    Taxa = 12.0,
                    Reg = "Simples Nacional",
                    Cnpj = "98.765.432/0001-12"

                },
                new empresa
                {
                   Id = 3,
                    Nome = "Construtora Beta",
                    End = "Rua da Construção, 789, Belo Horizonte - MG",
                    Taxa = 20.0,
                    Reg = "Simples Nacional",
                    Cnpj = "11.223.344/0001-56"

                }

            };




           

            return View(empresas);







        }
    }

}



