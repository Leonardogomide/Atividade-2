using Microsoft.AspNetCore.Mvc;
using cliente.Models;


namespace cliente.Controllers
{
    public class ClienteController : Controller
    {
        public IActionResult Index()
        {


            var clientes = new List<Cliente>{


                new  Cliente
                {
                    
                    Id = 1,
                    Nome = "Ana Silva Costa",
                    Cpf = 12345678900m,
                    End = "Rua das Flores, 123, Apto 45, Jardim das Rosas, São Paulo - SP, 01234-567",
                    Tel = "(11) 98765-4321",
                    Email = "ana.silva@exemplo.com"


                },
                new Cliente
                {
                    Id = 2,
                    Nome = "Carlos Oliveira Santos",
                    Cpf = 98765432100m,
                    End = "Avenida Brasil, 456, Sala 201, Centro, Rio de Janeiro - RJ, 12345-678",
                    Tel = "(21) 91234-5678",
                    Email = "carlos.oliveira@exemplo.com"

                },
                new Cliente
                {
                   Id = 3,
                    Nome = "Beatriz Almeida Pereira",
                    Cpf = 45612378900m,
                    End = "Rua do Comércio, 789, Casa 3, Vila Nova, Belo Horizonte - MG, 34567-890",
                    Tel = "(31) 92345-6789",
                    Email = "beatriz.almeida@exemplo.com"

                }

            };




           

            return View(clientes);







        }
    }

}



